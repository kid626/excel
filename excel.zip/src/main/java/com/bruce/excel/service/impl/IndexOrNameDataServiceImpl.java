package com.bruce.excel.service.impl;

import com.bruce.excel.entity.IndexOrNameData;
import com.bruce.excel.service.IndexOrNameDataService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Copyright Copyright © 2021 fanzh . All rights reserved.
 * @Desc
 * @ProjectName excel
 * @Date 2021/2/2 16:33
 * @Author Bruce
 */
@Service
public class IndexOrNameDataServiceImpl implements IndexOrNameDataService {


    @Override
    public void save(List<IndexOrNameData> list) {
    }
}
