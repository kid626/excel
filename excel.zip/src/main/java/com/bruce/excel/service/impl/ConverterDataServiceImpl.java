package com.bruce.excel.service.impl;

import com.bruce.excel.entity.ConverterData;
import com.bruce.excel.service.ConverterDataService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Copyright Copyright © 2021 fanzh . All rights reserved.
 * @Desc
 * @ProjectName excel
 * @Date 2021/2/2 16:33
 * @Author Bruce
 */
@Service
public class ConverterDataServiceImpl implements ConverterDataService {


    @Override
    public void save(List<ConverterData> list) {
    }
}
