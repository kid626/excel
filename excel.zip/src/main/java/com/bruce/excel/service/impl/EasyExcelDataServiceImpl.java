package com.bruce.excel.service.impl;

import com.bruce.excel.entity.EasyExcelData;
import com.bruce.excel.service.EasyExcelDataService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Copyright Copyright © 2021 fanzh . All rights reserved.
 * @Desc
 * @ProjectName excel
 * @Date 2021/2/2 16:33
 * @Author Bruce
 */
@Service
public class EasyExcelDataServiceImpl implements EasyExcelDataService {


    @Override
    public void save(List<EasyExcelData> list) {
    }
}
